"""
================================================================================
 PARAMÈTRES — Système distribué à 3 drones, adapté au formalisme KalmanNet
================================================================================

 Ce fichier traduit l'EKF distribué (votre code NumPy) dans le formalisme exigé
 par KalmanNet, c.-à-d. un UNIQUE système d'état autonome :

        x_{k+1} = f(x_k) + w_k          (dynamique, w ~ N(0, Q))
        y_k     = h(x_k) + v_k          (mesure,    v ~ N(0, R))

 ÉTAT EMPILÉ (m = 24) — les 3 drones côte à côte, 8 états chacun :
   bloc drone 1 : indices  0..7
   bloc drone 2 : indices  8..15
   bloc drone 3 : indices 16..23
 Au sein d'un bloc de 8 (identique à votre code) :
   [ px, py, vx, vy, ax, ay, bx, by ]
     0   1   2   3   4   5   6   7
   position / vitesse / accélération / biais.

 MESURE EMPILÉE (n = 7) — exactement vos capteurs et vos liens :
   0,1 : GPS drone 1        = (px1, py1)              [linéaire]
   2,3 : IMU drone 2        = (ax2+bx2, ay2+by2)      [linéaire]
   4   : distance d12       = ||p1 - p2||             [NON linéaire]
   5   : distance d23       = ||p2 - p3||             [NON linéaire]
   6   : distance d13       = ||p1 - p3||             [NON linéaire]

 ------------------------------------------------------------------------------
 DEUX CHOIX DE MODÉLISATION (voir INSTRUCTIONS.md, sections 2 et 3) :

 (A) La COMMANDE u de votre EKF (qui pilote l'accélération) est ABSORBÉE dans le
     bruit de process. Justification : dans votre modèle vrai l'accélération est
     déjà une marche aléatoire (a=0 dans F) ; une commande déterministe inconnue
     et un bruit de process bien calibré sur l'accélération sont équivalents du
     point de vue du filtre. On obtient ainsi la forme autonome x_{k+1}=F x + w
     dont KalmanNet a besoin, SANS toucher au cœur du code. C'est pourquoi
     'sigma_acc_gen' ci-dessous est volontairement élevé : il rejoue l'excitation
     qu'apportait la commande.

 (B) MISMATCH VOLONTAIRE modèle-vrai / modèle-filtre (repris de votre code) :
       - F_gen : les 3 drones ont une accélération NON constante (a=0).
       - F_mod : le drone 2 a une accélération CONSTANTE (a=1), comme F_loc[2].
       - Q_gen ≠ Q_mod (bruit de génération ≠ bruit supposé par le filtre).
     Ce décalage est le régime NOMINAL de KalmanNet : « dynamique partiellement
     connue ». Le réseau apprend à corriger ce que le modèle du filtre ignore.
 ------------------------------------------------------------------------------
"""

import torch

torch.pi = torch.acos(torch.zeros(1)).item() * 2

# ==============================================================================
# 0. DIMENSIONS ET PAS DE TEMPS (repris à l'identique de votre code)
# ==============================================================================
N_DRONES = 3
N_VAR    = 8
m        = N_DRONES * N_VAR        # 24 : dimension de l'état empilé
n        = 7                       # 7  : dimension de la mesure empilée

dt          = 0.1                  # pas du filtre
dt_capteur  = 0.5                  # cadence GPS + distances
dt_imu      = 0.1                  # cadence IMU
ratio_gps   = int(round(dt_capteur / dt))   # = 5  -> GPS/distances tous les 5 pas
ratio_imu   = int(round(dt_imu / dt))       # = 1  -> IMU à chaque pas

# ==============================================================================
# 1. ÉCARTS-TYPE (repris de votre code, regroupés ici)
# ==============================================================================
# --- bruits de PROCESS ---
sigma_w_accel = 5e-2     # bruit accel du modèle vrai d'origine
sigma_w_autre = 1e-6     # bruit des autres états
# Excitation d'accélération qui REJOUE la commande u (choix A ci-dessus).
# Réglez ce nombre pour rendre les trajectoires plus ou moins agitées.
sigma_acc_gen = 0.5

# --- bruits de MESURE (R) ---
sigma_gps = 0.5          # écart-type GPS
sigma_acc = 0.01         # écart-type mesure accel (IMU)
sigma_d   = 0.5          # écart-type distance

# --- covariance initiale P0 (sert seulement à tirer x0 aléatoire) ---
sigma_P_x, sigma_P_v, sigma_P_a, sigma_P_b = 2.0, 0.5, 0.5, 1.0

# ==============================================================================
# 2. MATRICE DE TRANSITION F  (bloc 8x8 par drone, puis bloc-diagonale 24x24)
# ==============================================================================
def _Fmat(accel_constante):
    """Bloc 8x8 d'un drone. accel_constante=True -> a=1 (drone 2 côté filtre)."""
    a = 1.0 if accel_constante else 0.0
    return torch.tensor([
        [1, 0, dt, 0, 0.5*dt**2, 0,         0, 0],
        [0, 1, 0,  dt, 0,        0.5*dt**2, 0, 0],
        [0, 0, 1,  0,  dt,       0,          0, 0],
        [0, 0, 0,  1,  0,        dt,         0, 0],
        [0, 0, 0,  0,  a,        0,          0, 0],
        [0, 0, 0,  0,  0,        a,          0, 0],
        [0, 0, 0,  0,  0,        0,          1, 0],
        [0, 0, 0,  0,  0,        0,          0, 1]], dtype=torch.float32)

def _block_diag3(B1, B2, B3):
    """Assemble 3 blocs 8x8 en une matrice bloc-diagonale 24x24."""
    M = torch.zeros(m, m, dtype=torch.float32)
    M[0:8,   0:8]   = B1
    M[8:16,  8:16]  = B2
    M[16:24, 16:24] = B3
    return M

# Modèle VRAI (génération des données) : les 3 drones, accel NON constante.
F_gen = _block_diag3(_Fmat(False), _Fmat(False), _Fmat(False))

# Modèle FILTRE (donné à l'EKF et à KalmanNet) : drone 2 accel CONSTANTE.
# -> reproduit F_loc = {1: a=0, 2: a=1, 3: a=0} de votre code.
F_mod = _block_diag3(_Fmat(False), _Fmat(True), _Fmat(False))

# ==============================================================================
# 3. FONCTION D'ÉVOLUTION f(x)   (batched, signature compatible KalmanNet)
# ==============================================================================
# KalmanNet appelle f(x) avec x de taille [batch, m, 1] et attend, si
# jacobian=True, le couple (f(x), F) où F est la Jacobienne [batch, m, m].
# Comme f est linéaire (f(x)=F·x), la Jacobienne est simplement F.
def _make_f(F):
    def f(x, jacobian=False):
        # x : [batch, m, 1]
        Fb = F.to(x.device).reshape(1, m, m).repeat(x.shape[0], 1, 1)
        fx = torch.bmm(Fb, x)
        if jacobian:
            return fx, Fb
        return fx
    return f

f_gen = _make_f(F_gen)   # pour GÉNÉRER les données (modèle vrai)
f     = _make_f(F_mod)   # pour le FILTRE / KalmanNet (modèle avec mismatch)

# ==============================================================================
# 4. FONCTION DE MESURE h(x)   (batched) + Jacobienne analytique
# ==============================================================================
# Indices de position dans l'état empilé.
_P1 = (0, 1)      # position drone 1
_P2 = (8, 9)      # position drone 2
_P3 = (16, 17)    # position drone 3
_A2 = (12, 13)    # accélération drone 2
_B2 = (14, 15)    # biais drone 2

def h(x, jacobian=False):
    """
    x : [batch, m, 1]  ->  y : [batch, n, 1]
    Mesure empilée : [GPS1_x, GPS1_y, IMU2_x, IMU2_y, d12, d23, d13].
    """
    bs = x.shape[0]
    xs = x.squeeze(-1)                     # [batch, m]

    p1 = xs[:, _P1[0]:_P1[1]+1]            # [batch, 2]
    p2 = xs[:, _P2[0]:_P2[1]+1]
    p3 = xs[:, _P3[0]:_P3[1]+1]
    a2 = xs[:, _A2[0]:_A2[1]+1]
    b2 = xs[:, _B2[0]:_B2[1]+1]

    eps = 1e-9
    d12 = torch.linalg.norm(p1 - p2, dim=1).clamp_min(eps)   # [batch]
    d23 = torch.linalg.norm(p2 - p3, dim=1).clamp_min(eps)
    d13 = torch.linalg.norm(p1 - p3, dim=1).clamp_min(eps)

    y = torch.zeros(bs, n, dtype=x.dtype, device=x.device)
    y[:, 0] = p1[:, 0]                     # GPS x drone 1
    y[:, 1] = p1[:, 1]                     # GPS y drone 1
    y[:, 2] = a2[:, 0] + b2[:, 0]          # IMU x drone 2 (accel + biais)
    y[:, 3] = a2[:, 1] + b2[:, 1]          # IMU y drone 2
    y[:, 4] = d12
    y[:, 5] = d23
    y[:, 6] = d13
    y = y.unsqueeze(-1)                    # [batch, n, 1]

    if jacobian:
        return y, _H_jac(x)
    return y

def _H_jac(x):
    """Jacobienne analytique H = dh/dx, taille [batch, n, m]. (validée par diff. finies)"""
    bs = x.shape[0]
    xs = x.squeeze(-1)
    H = torch.zeros(bs, n, m, dtype=x.dtype, device=x.device)

    # --- blocs linéaires (constants) ---
    H[:, 0, 0] = 1.0                       # GPS x  -> px1
    H[:, 1, 1] = 1.0                       # GPS y  -> py1
    H[:, 2, 12] = 1.0; H[:, 2, 14] = 1.0   # IMU x  -> ax2 + bx2
    H[:, 3, 13] = 1.0; H[:, 3, 15] = 1.0   # IMU y  -> ay2 + by2

    # --- blocs distance (dépendent de x) ---
    eps = 1e-9
    def fill(row, ia, ib):
        pa = xs[:, ia:ia+2]; pb = xs[:, ib:ib+2]
        d = torch.linalg.norm(pa - pb, dim=1).clamp_min(eps)
        u = (pa - pb) / d.unsqueeze(1)     # vecteur unitaire a->b
        H[:, row, ia]   =  u[:, 0]
        H[:, row, ia+1] =  u[:, 1]
        H[:, row, ib]   = -u[:, 0]
        H[:, row, ib+1] = -u[:, 1]
    fill(4, _P1[0], _P2[0])    # d12 : drones 1 et 2
    fill(5, _P2[0], _P3[0])    # d23 : drones 2 et 3
    fill(6, _P1[0], _P3[0])    # d13 : drones 1 et 3
    return H

# Helper utilisé par l'EKF (getJacobian générique).
def getJacobian(x, g):
    _, Jac = g(x, jacobian=True)
    return Jac

# ==============================================================================
# 5. COVARIANCES Q (process) ET R (mesure)
# ==============================================================================
def _make_Q_block(drone_id):
    """Bloc 8x8 de Q côté FILTRE — repris de make_Q_local() de votre code."""
    Q = torch.eye(8) * 1e-3
    Q[4, 4] = Q[5, 5] = 0.5**2
    Q[6, 6] = Q[7, 7] = 1e-5**2
    if drone_id == 2:
        Q[2, 2] = Q[3, 3] = 0.1**2
        Q[4, 4] = Q[5, 5] = 1e-2**2
    return Q

# Q du FILTRE (ce que l'EKF/KNet supposent).
Q_mod = _block_diag3(_make_Q_block(1), _make_Q_block(2), _make_Q_block(3))

# Q de GÉNÉRATION (modèle vrai) : bruit faible partout SAUF accélération, où l'on
# injecte sigma_acc_gen pour rejouer l'excitation de la commande u (choix A).
def _make_Q_gen_block():
    Q = torch.eye(8) * (sigma_w_autre**2)
    Q[4, 4] = Q[5, 5] = sigma_acc_gen**2   # accel agitée
    return Q
Q_gen = _block_diag3(_make_Q_gen_block(), _make_Q_gen_block(), _make_Q_gen_block())

# R : bruit de mesure.
# Votre code distingue le bruit RÉEL (génération) du bruit SUPPOSÉ (filtre) :
#   - génération IMU : sigma_acc = 0.01
#   - filtre IMU     : sigma_R_acc = 0.1
# On garde ce mismatch (régime KalmanNet). GPS et distances sont identiques.
sigma_R_acc = 0.1        # écart-type IMU supposé par le filtre

# R de GÉNÉRATION (bruit réellement injecté dans les données).
R_gen_diag = torch.tensor([
    sigma_gps**2, sigma_gps**2,    # GPS
    sigma_acc**2, sigma_acc**2,    # IMU réel (0.01)
    sigma_d**2,   sigma_d**2, sigma_d**2
], dtype=torch.float32)
R_gen = torch.diag(R_gen_diag)

# R du FILTRE (ce que KalmanNet/EKF supposent).
R_diag = torch.tensor([
    sigma_gps**2, sigma_gps**2,    # GPS
    sigma_R_acc**2, sigma_R_acc**2,  # IMU supposé (0.1)
    sigma_d**2,   sigma_d**2, sigma_d**2
], dtype=torch.float32)
R = torch.diag(R_diag)

# ==============================================================================
# 6. ÉTAT INITIAL  x0  ET COVARIANCE INITIALE  P0
# ==============================================================================
# x0 vrai (positions/vitesses de votre X_vrai_init).
m1x_0 = torch.tensor([
    0, 10, 1, 0, 0, 0, 0,   0,      # drone 1
    10, 0, 1, 0, 0, 0, 0.5, -0.2,   # drone 2
    0, -10, 1, 0, 0, 0, 0,   0      # drone 3
], dtype=torch.float32).reshape(m, 1)

# P0 (bloc make_P_local répété) : sert à tirer l'erreur initiale d'estimation.
def _make_P0_block():
    P = torch.eye(8)
    P[0, 0] = P[1, 1] = sigma_P_x**2
    P[2, 2] = P[3, 3] = sigma_P_v**2
    P[4, 4] = P[5, 5] = sigma_P_a**2
    P[6, 6] = P[7, 7] = sigma_P_b**2
    return P
m2x_0 = _block_diag3(_make_P0_block(), _make_P0_block(), _make_P0_block())

# ==============================================================================
# 7. MASQUE DE CADENCE DES MESURES
# ==============================================================================
# n=7 reste constant. À chaque pas t, certaines mesures n'existent pas :
#   - IMU (composantes 2,3)         : disponible à CHAQUE pas
#   - GPS (0,1) + distances (4,5,6) : disponibles tous les ratio_gps pas
# build_measurement_mask(T) renvoie un booléen [T, n] : True = mesure dispo.
# Le pipeline force l'innovation à 0 sur les composantes False (cf. KalmanNet_nn).
def build_measurement_mask(T):
    mask = torch.zeros(T, n, dtype=torch.bool)
    mask[:, 2] = True            # IMU toujours
    mask[:, 3] = True
    idx_gps = torch.arange(0, T, ratio_gps)
    for j in (0, 1, 4, 5, 6):    # GPS + distances
        mask[idx_gps, j] = True
    return mask
