# KalmanNet adapté à votre EKF distribué à 3 drones

Ce dossier est une copie du dépôt officiel **KalmanNet_TSP**, augmentée pour
faire tourner KalmanNet (apprentissage du gain de Kalman) sur **exactement la
dynamique de votre EKF distribué** : mêmes états, mêmes mesures, mêmes connexions
inter-drones. L'évaluation se fait en **MSE pure** (on a abandonné P / NCI /
couverture, comme convenu). Votre filtre distribué sert de **baseline**,
activable par un flag.

---

## 1. Comment lancer

```bash
# (Optionnel) installer les dépendances du dépôt
pip install torch numpy scipy matplotlib

# Lancer le tout : génération de données + baseline + entraînement + test KalmanNet
python3 main_drones.py
```

Tout se règle en tête de `main_drones.py` :

| Flag | Effet |
|------|-------|
| `RUN_BASELINE = True` | exécute **votre** EKF distribué sur le test (référence) |
| `TRAIN_KNET = True`   | (ré)entraîne KalmanNet ; `False` = charge `KNet/best-model.pt` |
| `args.use_cuda`       | `False` (CPU) par défaut ; `True` si GPU dispo |
| `args.n_steps`        | nombre d'itérations d'entraînement (montez-le pour mieux converger) |
| `args.N_E/N_CV/N_T`   | tailles des jeux train / validation / test |

Sortie attendue : les MSE de position de **KalmanNet** et de la **baseline**,
côte à côte, plus une figure de trajectoire.

---

## 2. La correspondance entre les deux mondes (le cœur du sujet)

Votre code est **distribué** : 3 EKF locaux qui échangent des paquets et fusionnent
par Covariance Intersection. KalmanNet est **centralisé** : il estime un seul état
et apprend le gain par réseau de neurones. Pour faire tourner KalmanNet « sur la
même dynamique », on empile les 3 drones en **un seul état de dimension 24** :

```
état x (m = 24) = [ drone1 (8) | drone2 (8) | drone3 (8) ]
bloc de 8 = [ px, py, vx, vy, ax, ay, bx, by ]   (identique à votre code)
```

La mesure empile vos capteurs et vos liens (**n = 7**) :

```
y = [ GPS1_x, GPS1_y, IMU2_x, IMU2_y, d12, d23, d13 ]
      0       1       2       3       4    5    6
```

- GPS du drone 1 et IMU du drone 2 : **linéaires**.
- d12, d23, d13 = distances entre drones : **non linéaires** (`||p_i − p_j||`).
  C'est là que vivent vos **connexions inter-drones**, exactement comme dans votre
  fusion de distances.

Toute l'adaptation se résume à remplir 5 cases du formalisme KalmanNet :
`f` (évolution), `h` (mesure), `Q` (bruit process), `R` (bruit mesure), et les
dimensions `m`/`n`. C'est fait dans `Simulations/Drones3/parameters.py`.

---

## 3. Les deux choix de modélisation à connaître

### (A) La commande `u` est absorbée dans le bruit de process

Votre dynamique vraie est `x_{k+1} = F·x + B·u + bruit`, où `u` pilote
l'accélération (3 phases : ligne droite / virage / ligne droite).
**KalmanNet n'a pas d'entrée de commande** : sa dynamique est autonome
`x_{k+1} = f(x) + bruit`.

Plutôt que de réécrire en profondeur le réseau et le générateur pour propager `u`
(invasif, et vous éloigne du KalmanNet officiel), on exploite un fait de votre
modèle : dans `F`, l'accélération a `a = 0`, donc **l'accélération est déjà une
marche aléatoire** alimentée par le bruit de process. Une commande déterministe
inconnue et un bruit de process bien calibré sur l'accélération sont
**équivalents du point de vue du filtre**. On absorbe donc `u` dans le bruit :

```
x_{k+1} = F·x + w        avec w plus agité sur l'accélération
```

Concrètement, dans `parameters.py`, `sigma_acc_gen = 0.5` rejoue l'excitation
qu'apportait `u`. **Vos états, votre F, vos mesures et vos connexions ne changent
pas** ; seule la *source* du mouvement d'accélération change. C'est précisément le
régime pour lequel KalmanNet est conçu.

> Si un jour vous voulez la commande explicite, il faudra modifier la signature de
> `f`, le générateur `GenerateBatch`, le pipeline et le forward du réseau pour
> passer `u` à chaque pas. C'est une extension, pas un prérequis.

### (B) Le mismatch modèle-vrai / modèle-filtre est conservé (et voulu)

Votre code a déjà deux modèles : le **vrai** (génère les données) et celui du
**filtre** (le drone 2 a une accélération constante). On garde ce décalage :

| | modèle VRAI (génération) | modèle FILTRE (KNet / EKF) |
|---|---|---|
| `F` | `F_gen` : 3 drones accel non constante | `F_mod` : drone 2 accel **constante** |
| `Q` | `Q_gen` : accel agitée (`sigma_acc_gen`) | `Q_mod` = votre `make_Q_local()` |
| fonction | `f_gen` | `f` |

Ce mismatch est le terrain de jeu de KalmanNet : « dynamique partiellement
connue ». Le réseau apprend à corriger ce que le modèle du filtre ignore.

---

## 4. Les cadences de mesure (masquage)

Vos capteurs n'ont pas la même fréquence :

- **IMU** (drone 2) : à **chaque** pas (0.1 s) ;
- **GPS** (drone 1) **et distances** : tous les **5 pas** (0.5 s).

On garde `n = 7` constant, mais à chaque pas un **masque** indique quelles
composantes sont disponibles. Quand une mesure est indisponible, on **annule son
innovation** (`dy = 0`) : la prédiction n'est pas corrigée par cette composante.
C'est l'approche standard de KalmanNet pour mesures manquantes.

Le masque est construit par `build_measurement_mask(T)` dans `parameters.py`
et propagé au réseau via le pipeline.

---

## 5. La baseline = votre EKF distribué

`Baseline/baseline_distribue.py` reprend **fidèlement** votre classe
`DroneDistribue` (3 EKF locaux + fusion CI sur les distances, méthode M0 = bloc
2×2 exact). Une seule différence d'usage :

- votre script d'origine **générait** lui-même la trajectoire (avec `u`) ;
- ici la baseline **consomme les mêmes séquences `y`/`x`** que KalmanNet, pour que
  la comparaison MSE soit honnête. La commande `u` n'existe plus (absorbée), donc
  `predict()` est appelé avec `u = 0` ; l'agitation vient du `Q`.

La baseline reste **distribuée** (sa nature), KalmanNet reste **centralisé** (sa
nature) ; ils tournent sur les **mêmes données**. C'est la comparaison juste.

---

## 6. Liste exacte des fichiers modifiés / ajoutés

### Ajoutés
| Fichier | Rôle |
|---------|------|
| `Simulations/Drones3/parameters.py` | **Cœur de l'adaptation** : `f`, `h`, `Q`, `R`, `m=24`, `n=7`, état/mesure empilés, Jacobienne analytique des distances, masque de cadence |
| `Baseline/baseline_distribue.py` | Votre EKF distribué, branché sur les trajectoires KalmanNet |
| `main_drones.py` | Orchestration : data → baseline → train/test KNet → comparaison |
| `INSTRUCTIONS.md` | Ce document |

### Modifiés (chirurgie minimale, rétrocompatible)
| Fichier | Modification | Pourquoi |
|---------|--------------|----------|
| `KNet/KalmanNet_nn.py` | `InitSequence` initialise `self.meas_mask=None` ; `KNet_step` multiplie l'innovation `dy` par le masque ; ajout de `set_meas_mask()` | gérer les cadences de mesure sans toucher au reste |
| `Pipelines/Pipeline_EKF.py` | ajout `setMeasMask()` + attribut `meas_mask` ; les 3 boucles forward (train/CV/test) appellent `set_meas_mask(mask[t])` avant chaque pas | propager le masque au réseau |

> Toutes les modifications du réseau et du pipeline sont **optionnelles** : sans
> masque (`meas_mask = None`), le comportement officiel de KalmanNet est
> strictement inchangé. Les fichiers Lorenz / Linear d'origine fonctionnent
> toujours tels quels.

Marqueurs `# [AJOUT DRONES]` dans le code pour repérer chaque insertion.

---

## 7. Ce qui a été vérifié

- **Jacobienne des distances** validée par différences finies (erreur ~1e-10).
- **Structure des mesures** : chaque ligne de `h` active les bonnes colonnes
  (GPS→pos1, IMU→accel2+biais2, distances→les deux positions concernées).
- **Mismatch** `F_gen ≠ F_mod` et `Q_gen ≠ Q_mod` bien présent.
- **Masque de cadence** : IMU à chaque pas, GPS+distances tous les 5 pas.
- **Q_gen / Q_mod définies positives** (génération `MultivariateNormal` OK).
- **Baseline distribuée** tourne sur données externes (RMSE position ~0.8 m sur un
  test synthétique).
- Tous les fichiers Python **compilent**.

> Note : l'exécution PyTorch elle-même (entraînement réel du réseau) n'a pas pu
> être lancée dans l'environnement de préparation (torch non installable hors
> ligne). La logique mathématique est validée en NumPy ; lancez `main_drones.py`
> dans votre environnement avec torch pour l'entraînement.

---

## 8. Métriques (pour la suite)

Vous avez mentionné vouloir des métriques type **MDE** (Mean Distance Error) plutôt
que MSE. C'est immédiat à brancher : sur la sortie `KNet_out` (et `base_out` de la
baseline), la MDE par drone est

```python
# position estimée vs vraie, distance euclidienne moyenne
err = (KNet_out[:, pos_idx, :] - test_target[:, pos_idx, :])  # pos_idx par drone
mde_drone = err.reshape(N_T, 3, 2, T).norm(dim=2).mean()
```

Dites-moi si vous voulez que je l'ajoute proprement dans `main_drones.py`, avec un
affichage par drone et par phase de trajectoire.

---

## 9. Questions ouvertes pour vous

1. **`sigma_acc_gen = 0.5`** : c'est mon estimation pour rejouer votre commande.
   Si vos trajectoires de référence sont plus/moins agitées, ce nombre se règle.
   Avez-vous une amplitude cible (m/s²) pour le mouvement ?
2. **Loss sur position seule ou tout l'état ?** Actuellement `Loss_On_AllState =
   True` (les 24 états). Si vous voulez entraîner uniquement sur la position
   (comme votre MSE position), je peux ajouter le masque d'état correspondant.
3. **Bruit IMU** : votre code utilise `sigma_acc = 0.01` à la génération mais
   `sigma_R_acc = 0.1` côté filtre. Ce mismatch est **désormais respecté** :
   `parameters.py` définit `R_gen` (0.01, injecté dans les données) et `R` (0.1,
   supposé par le filtre/KNet). Le `main` utilise `R_gen` pour générer et `R`
   pour filtrer. Rien à faire de votre côté, c'est signalé pour transparence.
