"""
================================================================================
 BASELINE — EKF distribué à 3 drones (VOTRE code), branché sur les trajectoires
            générées pour KalmanNet, pour une comparaison MSE honnête.
================================================================================

 IMPORTANT — ce que ce fichier est et n'est pas :
 - C'est VOTRE filtre distribué (3 EKF locaux + fusion par Covariance Intersection
   sur les distances), repris fidèlement de votre classe DroneDistribue.
 - Il reste DISTRIBUÉ (chaque drone a son filtre, échange de paquets, CI).
   KalmanNet, lui, est CENTRALISÉ (un état de 24). Les deux philosophies
   diffèrent, mais ON LES FAIT TOURNER SUR LES MÊMES DONNÉES pour comparer.

 Différence clé avec votre script d'origine :
   votre script générait lui-même la trajectoire (avec la commande u).
   ICI, la baseline CONSOMME les mêmes séquences y/x que KalmanNet (générées par
   le SystemModel via parameters.py). La commande u n'existe plus : elle a été
   absorbée dans le bruit de process (voir parameters.py, choix A). La baseline
   appelle donc predict() avec u = 0 ; l'agitation d'accélération vient du Q.

 Activez/désactivez cette baseline via le flag RUN_BASELINE dans main_drones.py.
================================================================================
"""

import numpy as np
from numpy.linalg import inv
from scipy.optimize import minimize_scalar

# ------------------------------------------------------------------ #
#  Géométrie des indices dans l'état empilé de 24 (cf. parameters.py) #
# ------------------------------------------------------------------ #
N_DRONES = 3
dt = 0.1
I8 = np.eye(8)

# Bloc 8x8 par drone, côté FILTRE (drone 2 : accel constante a=1).
def _Fmat(accel_constante):
    a = 1.0 if accel_constante else 0.0
    return np.array([
        [1, 0, dt, 0, 0.5*dt**2, 0,         0, 0],
        [0, 1, 0,  dt, 0,        0.5*dt**2, 0, 0],
        [0, 0, 1,  0,  dt,       0,          0, 0],
        [0, 0, 0,  1,  0,        dt,         0, 0],
        [0, 0, 0,  0,  a,        0,          0, 0],
        [0, 0, 0,  0,  0,        a,          0, 0],
        [0, 0, 0,  0,  0,        0,          1, 0],
        [0, 0, 0,  0,  0,        0,          0, 1]], dtype=float)

F_loc = {1: _Fmat(False), 2: _Fmat(True), 3: _Fmat(False)}

def _make_Q_local(drone_id):
    """Identique à votre make_Q_local()."""
    Q = np.eye(8) * 1e-3
    Q[4, 4] = Q[5, 5] = 0.5**2
    Q[6, 6] = Q[7, 7] = 1e-5**2
    if drone_id == 2:
        Q[2, 2] = Q[3, 3] = 0.1**2
        Q[4, 4] = Q[5, 5] = 1e-2**2
    return Q

def _make_P_local():
    """Identique à votre make_P_local()."""
    P = np.eye(8)
    P[0, 0] = P[1, 1] = 2.0**2
    P[2, 2] = P[3, 3] = 0.5**2
    P[4, 4] = P[5, 5] = 0.5**2
    P[6, 6] = P[7, 7] = 1.0**2
    return P

# Bruits de mesure (R) — mêmes valeurs que parameters.py.
sigma_R_gps = 0.5
sigma_R_acc = 0.1     # NB: votre code utilise 0.1 pour l'IMU côté filtre
sigma_R_d   = 0.5


# ================================================================== #
#  Classe DroneDistribue — REPRISE FIDÈLE de votre code              #
# ================================================================== #
class DroneDistribue:
    def __init__(self, drone_id, x_init, P_init, Q_local):
        self.id = drone_id
        self.x  = x_init.copy()
        self.P  = P_init.copy()
        self.Q  = Q_local.copy()
        self.F  = F_loc[drone_id]

    def predict(self, u=None):
        # u absorbé dans le process (cf. en-tête) -> pas de terme B@u.
        self.x = self.F @ self.x
        self.P = self.F @ self.P @ self.F.T + self.Q

    def update_local(self, mes, H, R):
        S = H @ self.P @ H.T + R
        K = self.P @ H.T @ inv(S)
        innov = mes - H @ self.x
        self.x = self.x + K @ innov
        A = I8 - K @ H
        self.P = A @ self.P @ A.T + K @ R @ K.T

    def update_CI_batch(self, liens, R_scalaire):
        """Fusion CI batch sur les distances. liens : [(d_mesure, paquet_voisin)].
           paquet_voisin = {'pos': (x,y), 'data': bloc 2x2 P position} (méthode M0)."""
        if not liens:
            return
        rows_Hi, innovs, R_diag = [], [], []
        for d_mesure, paquet in liens:
            xi, yi = self.x[0], self.x[1]
            xj, yj = paquet["pos"]
            d_pred = np.hypot(xi - xj, yi - yj)
            if d_pred < 1e-4:
                d_pred = 1e-4
            Hi = np.zeros(8)
            Hi[0] = (xi - xj) / d_pred
            Hi[1] = (yi - yj) / d_pred
            Hj = np.array([-(xi - xj) / d_pred, -(yi - yj) / d_pred])
            var_j = float(Hj @ paquet["data"] @ Hj.T)   # méthode M0 (bloc 2x2 exact)
            rows_Hi.append(Hi)
            innovs.append(d_mesure - d_pred)
            R_diag.append(R_scalaire + var_j)
        H = np.vstack(rows_Hi)
        innov = np.array(innovs)
        Rv = np.diag(R_diag)

        def cout_CI(omega):
            Pi = self.P / omega
            S = H @ Pi @ H.T + Rv / (1.0 - omega)
            K = Pi @ H.T @ inv(S)
            return np.trace(Pi - K @ H @ Pi)

        sol = minimize_scalar(cout_CI, bounds=(0.01, 0.99), method='bounded')
        omega = sol.x
        Pi = self.P / omega
        S = H @ Pi @ H.T + Rv / (1.0 - omega)
        K = Pi @ H.T @ inv(S)
        self.x = self.x + K @ innov
        self.P = Pi - K @ H @ Pi


# ================================================================== #
#  Adaptateur : faire tourner la baseline sur les données KalmanNet  #
# ================================================================== #
def run_baseline_on_dataset(test_input, test_target, ratio_gps=5):
    """
    test_input  : observations [N_T, n=7, T]  (mêmes que KalmanNet)
    test_target : états vrais   [N_T, m=24, T]
    Retour :
      x_out  : estimations baseline [N_T, 24, T]
      mse    : MSE moyenne sur toutes les composantes (float)
      mse_pos: MSE moyenne sur la POSITION des 3 drones (float)
    Les mesures suivent les MÊMES cadences que KalmanNet (masque IMU/GPS/dist).
    """
    # numpy depuis d'éventuels tenseurs torch
    if hasattr(test_input, "detach"):
        test_input = test_input.detach().cpu().numpy()
    if hasattr(test_target, "detach"):
        test_target = test_target.detach().cpu().numpy()

    N_T, n, T = test_input.shape
    m = test_target.shape[1]
    x_out = np.zeros((N_T, m, T))

    # Matrices de mesure locales (linéaires).
    H_gps = np.zeros((2, 8)); H_gps[0, 0] = 1.0; H_gps[1, 1] = 1.0
    H_imu = np.zeros((2, 8)); H_imu[0, 4] = H_imu[0, 6] = 1.0
    H_imu[1, 5] = H_imu[1, 7] = 1.0

    for seq in range(N_T):
        # État initial = vérité au pas 0 + erreur d'init (cohérent avec votre code).
        x0 = test_target[seq, :, 0].copy()
        rng = np.random.default_rng(seq)
        x0_est = x0.copy()
        for b in (0, 8, 16):
            x0_est[b:b+2] += rng.normal(0, 2.0, size=2)

        drones = {i: DroneDistribue(i, x0_est[(i-1)*8:i*8],
                                    _make_P_local(), _make_Q_local(i))
                  for i in (1, 2, 3)}

        for t in range(T):
            # 1) prédiction (u absorbé)
            for i in (1, 2, 3):
                drones[i].predict()

            y = test_input[seq, :, t]   # [7]

            # 2) IMU drone 2 (chaque pas)
            mes_imu = y[2:4]
            drones[2].update_local(mes_imu, H_imu,
                                   np.diag([sigma_R_acc**2, sigma_R_acc**2]))

            # 3) GPS drone 1 + distances (tous les ratio_gps pas)
            if t % ratio_gps == 0:
                drones[1].update_local(y[0:2], H_gps,
                                       np.diag([sigma_R_gps**2, sigma_R_gps**2]))
                d12, d23, d13 = y[4], y[5], y[6]
                # paquets méthode M0 : position + bloc 2x2 exact de P
                paq = {i: {"pos": drones[i].x[0:2].copy(),
                           "data": drones[i].P[0:2, 0:2].copy()} for i in (1, 2, 3)}
                drones[1].update_CI_batch([(d12, paq[2]), (d13, paq[3])], sigma_R_d**2)
                drones[2].update_CI_batch([(d12, paq[1]), (d23, paq[3])], sigma_R_d**2)
                drones[3].update_CI_batch([(d23, paq[2]), (d13, paq[1])], sigma_R_d**2)

            # 4) enregistrement
            for i, b in [(1, 0), (2, 8), (3, 16)]:
                x_out[seq, b:b+8, t] = drones[i].x

    # MSE globale et MSE position
    err = x_out - test_target
    mse = float(np.mean(err**2))
    pos_idx = [0, 1, 8, 9, 16, 17]
    mse_pos = float(np.mean(err[:, pos_idx, :]**2))
    return x_out, mse, mse_pos
