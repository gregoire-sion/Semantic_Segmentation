"""
================================================================================
 MAIN — KalmanNet sur le système distribué à 3 drones (24 états, 7 mesures)
================================================================================
 Pipeline complet :
   1. Construit le SystemModel (f, h, Q, R) depuis Simulations/Drones3/parameters
   2. Génère les datasets train / CV / test (mêmes trajectoires pour tous)
   3. (optionnel) Lance VOTRE baseline EKF distribué sur le test  -> RUN_BASELINE
   4. Entraîne KalmanNet (apprentissage du gain) puis teste
   5. Compare les MSE (KalmanNet vs baseline) et trace la position

 Flags utiles, en tête de la section CONFIG ci-dessous :
   RUN_BASELINE    : True -> exécute votre EKF distribué comme référence
   TRAIN_KNET      : True -> (ré)entraîne KalmanNet ; False -> charge best-model.pt
   args.use_cuda   : False par défaut (CPU). True si GPU dispo.
================================================================================
"""

import torch
from datetime import datetime

from Simulations.Extended_sysmdl import SystemModel
import Simulations.config as config
import Simulations.utils as utils

# --- paramètres du système 3 drones ---
from Simulations.Drones3 import parameters as P

# --- KalmanNet ---
from KNet.KalmanNet_nn import KalmanNetNN
from Pipelines.Pipeline_EKF import Pipeline_EKF as Pipeline

# --- baseline (votre EKF distribué) ---
from Baseline.baseline_distribue import run_baseline_on_dataset

# ==============================================================================
# CONFIG
# ==============================================================================
RUN_BASELINE = True     # <-- activez/désactivez votre baseline ici
TRAIN_KNET   = True     # <-- False pour seulement tester un modèle déjà entraîné

today = datetime.today(); now = datetime.now()
strTime = today.strftime("%m.%d.%y") + "_" + now.strftime("%H:%M:%S")
print("Current Time =", strTime)
path_results = 'KNet/'

args = config.general_settings()
### tailles de datasets (réduisez pour un test rapide)
args.N_E  = 200      # train
args.N_CV = 40       # cross-validation
args.N_T  = 50       # test
args.T      = 160    # longueur séquence (= n_steps de votre code : 16s / 0.1s)
args.T_test = 160
### entraînement
args.use_cuda = False
args.n_steps  = 300    # nb d'itérations d'entraînement (augmentez pour mieux converger)
args.n_batch  = 20
args.lr       = 1e-3
args.wd       = 1e-4
### init aléatoire de l'état (on connaît l'init -> KnownRandInit)
args.randomInit_train = True
args.randomInit_cv    = True
args.randomInit_test  = True

if args.use_cuda:
    if torch.cuda.is_available():
        device = torch.device('cuda'); print("Using GPU")
    else:
        raise Exception("No GPU found, set args.use_cuda = False")
else:
    device = torch.device('cpu'); print("Using CPU")

# ==============================================================================
# 1+2. SYSTEM MODEL + GÉNÉRATION DES DONNÉES
# ==============================================================================
# Modèle de GÉNÉRATION (vrai) : f_gen, Q_gen, R_gen (bruit réellement injecté).
sys_model_gen = SystemModel(P.f_gen, P.Q_gen, P.h, P.R_gen, args.T, args.T_test, P.m, P.n)
sys_model_gen.InitSequence(P.m1x_0, P.m2x_0)

# Modèle FILTRE (donné à KalmanNet) : f (mismatch F), Q_mod, R (bruit supposé).
sys_model = SystemModel(P.f, P.Q_mod, P.h, P.R, args.T, args.T_test, P.m, P.n)
sys_model.InitSequence(P.m1x_0, P.m2x_0)

DatafolderName = 'Simulations/Drones3/data/'
DatafileName   = 'drones3_T160.pt'

print("Start Data Gen (modèle vrai f_gen / Q_gen)")
utils.DataGen(args, sys_model_gen, DatafolderName + DatafileName)
[train_input, train_target, cv_input, cv_target, test_input, test_target,
 train_init, cv_init, test_init] = torch.load(DatafolderName + DatafileName, map_location=device)

print("Data Shape")
print("  test  x:", test_target.size(), " y:", test_input.size())
print("  train x:", train_target.size(), " y:", train_input.size())

# Masque de cadence (mêmes cadences GPS/IMU/distances que votre code).
meas_mask = P.build_measurement_mask(args.T_test).to(device)
print("Masque de cadence : IMU chaque pas | GPS+distances tous les",
      P.ratio_gps, "pas")

# ==============================================================================
# 3. BASELINE — votre EKF distribué (optionnel)
# ==============================================================================
mse_base_pos = None
if RUN_BASELINE:
    print("\n=== Baseline : EKF distribué (votre code) ===")
    base_out, mse_base, mse_base_pos = run_baseline_on_dataset(
        test_input, test_target, ratio_gps=P.ratio_gps)
    print(f"  Baseline MSE globale  : {mse_base:.4f}")
    print(f"  Baseline MSE position : {mse_base_pos:.4f}  "
          f"(RMSE pos ~ {mse_base_pos**0.5:.3f} m)")
    print(f"  Baseline MSE position : {10*torch.log10(torch.tensor(mse_base_pos)):.2f} dB")
else:
    print("\n(Baseline désactivée : RUN_BASELINE = False)")

# ==============================================================================
# 4. KALMANNET — construction, entraînement, test
# ==============================================================================
KNet_model = KalmanNetNN()
KNet_model.NNBuild(sys_model, args)
print("\nNb paramètres entraînables KNet :",
      sum(p.numel() for p in KNet_model.parameters() if p.requires_grad))

KNet_Pipeline = Pipeline(strTime, "KNet", "KNetDrones")
KNet_Pipeline.setssModel(sys_model)
KNet_Pipeline.setModel(KNet_model)
KNet_Pipeline.setTrainingParams(args)
KNet_Pipeline.setMeasMask(meas_mask)   # <-- masque de cadence des mesures

# Loss sur la POSITION uniquement (cohérent avec votre évaluation MSE position).
# MaskOnState=True + masque [position des 3 drones] via le pipeline officiel
# ne gère qu'un masque simple ; ici on évalue sur tout l'état (Loss_On_AllState).
Loss_On_AllState = True   # True : MSE sur les 24 états (position incluse)

if TRAIN_KNET:
    print("\n=== Entraînement KalmanNet ===")
    KNet_Pipeline.NNTrain(sys_model, cv_input, cv_target, train_input, train_target,
                          path_results, MaskOnState=not Loss_On_AllState,
                          randomInit=True, cv_init=cv_init, train_init=train_init)

print("\n=== Test KalmanNet ===")
[MSE_test_arr, MSE_test_avg, MSE_test_dB, KNet_out, RunTime] = KNet_Pipeline.NNTest(
    sys_model, test_input, test_target, path_results,
    MaskOnState=not Loss_On_AllState, randomInit=True, test_init=test_init)

# MSE position de KalmanNet (pour comparaison directe avec la baseline).
pos_idx = [0, 1, 8, 9, 16, 17]
err_knet = KNet_out.cpu() - test_target.cpu()
mse_knet_pos = float((err_knet[:, pos_idx, :]**2).mean())
print(f"\nKalmanNet MSE position : {mse_knet_pos:.4f}  "
      f"(RMSE pos ~ {mse_knet_pos**0.5:.3f} m)")

# ==============================================================================
# 5. COMPARAISON
# ==============================================================================
print("\n" + "="*60)
print("  COMPARAISON (MSE sur la position des 3 drones)")
print("="*60)
print(f"  KalmanNet : {mse_knet_pos:.4f}  (RMSE {mse_knet_pos**0.5:.3f} m)")
if mse_base_pos is not None:
    print(f"  Baseline  : {mse_base_pos:.4f}  (RMSE {mse_base_pos**0.5:.3f} m)")
print("="*60)

print("\nTerminé. Modèle sauvegardé dans", path_results + "best-model.pt")
